const rows = 6;
const cols = 5;
const totalPairs = (rows * cols) / 2;
let images, shuffledImages, revealedCards, steps, matches;
let mismatchedCards = [];

function initializeGame() {
    images = Array.from({ length: totalPairs }, (_, i) => `images/image${i + 1}.jpg`).flatMap(x => [x, x]);
    shuffledImages = shuffle(images);
    revealedCards = [];
    steps = 0;
    matches = 0;
    updateStats();
    renderBoard();
}

function shuffle(array) {
    return array.sort(() => Math.random() - 0.5);
}

function renderBoard() {
    const board = document.getElementById('board');
    board.innerHTML = '';
    shuffledImages.forEach((image, index) => {
        const card = document.createElement('div');
        card.className = 'card hidden';
        card.dataset.image = image;
        card.dataset.index = index;
        card.innerHTML = `<img src="${image}" alt="image">`;
        card.addEventListener('click', handleCardClick);
        board.appendChild(card);
    });
}

function handleCardClick(event) {
    const card = event.target;

    // Ignore already revealed or matched cards
    if (card.classList.contains('revealed') || card.classList.contains('matched')) return;

    // Hide mismatched cards before revealing the new one
    if (mismatchedCards.length === 2) {
        hideCards(mismatchedCards);
        mismatchedCards = [];
    }

    revealCard(card);

    if (revealedCards.length === 2) {
        steps++;
        updateStats();
        checkMatch();
    }
}

function revealCard(card) {
    card.classList.remove('hidden');
    card.classList.add('revealed');
    card.querySelector('img').style.display = 'block';
    revealedCards.push(card);
}

function hideCards(cards) {
    cards.forEach(card => {
        card.classList.remove('revealed');
        card.classList.add('hidden');
        card.querySelector('img').style.display = 'none';
    });
}

function checkMatch() {
    const [card1, card2] = revealedCards;

    if (card1.dataset.image === card2.dataset.image) {
        card1.classList.add('matched');
        card2.classList.add('matched');
        matches++;
        updateStats();

        // Check if the game is complete
        if (matches === totalPairs) {
            setTimeout(() => alert('You won!'), 200);
        }
        revealedCards = [];
    } else {
        mismatchedCards = [...revealedCards];
        revealedCards = [];
    }
}

function updateStats() {
    document.getElementById('steps').textContent = steps;
    document.getElementById('matches').textContent = matches;
}
